### Interested in joining UltraPlay's team of front-end developers?

In this repository you will find the requirements for the task you've been given.

### How to start?

You can setup the server by running `npm install` followed by a `npm start`.  
If there are any problems with the server you can file an issue to this repository or write us an email. 
